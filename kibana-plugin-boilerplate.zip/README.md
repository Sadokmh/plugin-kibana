# kibana-plugin-boilerplate
Super Simple Kibana Plugin Boilerplate
